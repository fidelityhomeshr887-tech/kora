import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.error("OPENAI_API_KEY is missing. Copy .env.example to .env and add your NEW key.");
  process.exit(1);
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json({ limit: "2mb" }));
app.use(express.static("public"));

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [] } = req.body;
    if (!message?.trim()) return res.status(400).json({ error: "Message is required." });

    const input = [
      {
        role: "developer",
        content:
          "You are Kora AI, the AI assistant created for Blacq Hub. " +
          "Be helpful, accurate, practical, professional, and concise. " +
          "Do not claim to have performed actions you cannot perform."
      },
      ...history.slice(-20),
      { role: "user", content: message.trim() }
    ];

    const response = await openai.responses.create({
      model: "gpt-5.6",
      input
    });

    res.json({ reply: response.output_text });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Kora could not process that request." });
  }
});

app.listen(port, () => {
  console.log(`Kora AI running at http://localhost:${port}`);
});