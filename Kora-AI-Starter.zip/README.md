# Kora AI

## Setup
1. Install Node.js 20+.
2. Open this folder in VS Code.
3. Copy `.env.example` to `.env`.
4. Put your NEW OpenAI API key in `.env`.
5. Run:
   npm install
   npm run dev
6. Open http://localhost:3000

IMPORTANT: Never paste your API key into the frontend, GitHub, or chat. The previously exposed key should be revoked.
